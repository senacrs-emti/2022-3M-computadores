<header>
    <h1>Admin Site</h1>
    <ul>
        <li><a href="categoria-lista.php?senha=salva">Categorias</a></li>
        <li><a href="produto-lista.php?senha=salva">Produtos</a></li>
        <li><a href="usuario-lista.php?senha=salva">Usuários</a></li>
        <li><a href="categoria-noticia-lista.php?senha=salva">Categoria Notícias</a></li>
        <li><a href="noticia-lista.php?senha=salva">Notícias</a></li>
        <li><a href="index.php/..">Logoff</a></li>
</ul>
</header>